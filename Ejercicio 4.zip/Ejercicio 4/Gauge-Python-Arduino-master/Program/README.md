The explanation of this program is written in the PDF file.
</br>
If you want to edit the program, I recommend to install the IDE Eric first.</br>

To the website ERIC --> <a href="https://eric-ide.python-projects.org/" target="_blank">
 <img src="https://user-images.githubusercontent.com/36192933/50552051-93225900-0c8b-11e9-9349-c158f304ca89.jpg" alt="IMAGE ALT TEXT HERE" width="160" border="10" />

